// src/routes/ticketRoutes.js (Повний актуальний файл)

const express = require('express');
const router = express.Router();
const { bookTicket } = require('../controllers/ticketController');
const { authenticateToken } = require('../middleware/authMiddleware');

// Переконайся, що тут правильний метод POST і шлях
router.post('/tickets/book', authenticateToken, bookTicket);

module.exports = router;
// src/routes/adminRoutes.js
const express = require('express');
const router = express.Router();
const { createMovie, updateMovie, deleteMovie } = require('../controllers/adminController');
const { authenticateToken, authorizeAdmin } = require('../middleware/authMiddleware');

const adminAccess = [authenticateToken, authorizeAdmin];

// Усі маршрути тут вимагають спочатку валідного токена, а потім прав адміністратора
router.post('/movies', adminAccess, createMovie);
router.put('/movies/:id', adminAccess, updateMovie);
router.delete('/movies/:id', adminAccess, deleteMovie);

module.exports = router;
// src/controllers/ticketController.js
const { pool } = require('../config/db');

const bookTicket = async (req, res) => {
    // Починаємо транзакцію. Це гарантує, що або всі операції виконаються успішно, або жодна.
    const client = await pool.connect();
    
    try {
        await client.query('BEGIN');

        const userId = req.user.id;
        const { movieId, seats, totalPrice } = req.body;

        // 1. Перевіряємо баланс користувача всередині транзакції
        const userResult = await client.query('SELECT balance FROM users WHERE id = $1 FOR UPDATE', [userId]);
        const userBalance = parseFloat(userResult.rows[0].balance);

        if (userBalance < totalPrice) {
            await client.query('ROLLBACK');
            return res.status(400).json({ message: 'Недостатньо коштів на балансі.' });
        }

        // 2. Списуємо кошти
        const newBalance = userBalance - totalPrice;
        await client.query('UPDATE users SET balance = $1 WHERE id = $2', [newBalance, userId]);

        // 3. Створюємо квиток
        const ticketQuery = `
            INSERT INTO tickets (user_id, movie_id, seats, total_price)
            VALUES ($1, $2, $3, $4)
            RETURNING id, purchase_date;
        `;
        const ticketValues = [userId, movieId, JSON.stringify(seats), totalPrice];
        const newTicket = await client.query(ticketQuery, ticketValues);

        // Якщо все пройшло добре, підтверджуємо транзакцію
        await client.query('COMMIT');
        
        res.status(201).json({ 
            message: 'Квитки успішно придбано!',
            ticketId: newTicket.rows[0].id,
            purchaseDate: newTicket.rows[0].purchase_date,
            newBalance: newBalance 
        });

    } catch (err) {
        // У разі будь-якої помилки, відкочуємо всі зміни
        await client.query('ROLLBACK');
        console.error('Помилка транзакції при покупці квитка:', err);
        res.status(500).json({ message: 'Помилка сервера під час покупки квитка.' });
    } finally {
        // Повертаємо клієнта в пул
        client.release();
    }
};

module.exports = { bookTicket };
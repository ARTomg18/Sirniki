// src/controllers/userController.js

const { pool } = require('../config/db');

const getUserProfile = async (req, res) => {
  try {
    // ID користувача ми отримуємо з токена
    const userId = req.user.id;

    // --- Запит 1: Отримуємо дані самого користувача ---
    const userQuery = `
      SELECT id, username, email, balance, is_admin, avatar_url, created_at 
      FROM users 
      WHERE id = $1;
    `;
    const userResult = await pool.query(userQuery, [userId]);

    if (userResult.rows.length === 0) {
      return res.status(404).json({ message: 'Користувача не знайдено.' });
    }
    
    const userProfile = userResult.rows[0];

    // --- Запит 2: Отримуємо квитки цього користувача з даними про фільм ---
    const ticketsQuery = `
      SELECT 
        t.id, 
        t.seats, 
        t.total_price, 
        t.purchase_date,
        m.title AS movie_title,
        m.poster_url
      FROM tickets t
      JOIN movies m ON t.movie_id = m.id
      WHERE t.user_id = $1
      ORDER BY t.purchase_date DESC;
    `;
    const ticketsResult = await pool.query(ticketsQuery, [userId]);

    // Додаємо масив квитків до профілю користувача
    userProfile.tickets = ticketsResult.rows;

    res.status(200).json(userProfile);

  } catch (err) {
    console.error('Помилка отримання профілю:', err.message);
    res.status(500).json({ message: 'Внутрішня помилка сервера.' });
  }
};

module.exports = { getUserProfile };
// src/controllers/movieController.js

const { pool } = require('../config/db');

const getAllMovies = async (req, res) => {
  try {
    const query = 'SELECT * FROM movies ORDER BY release_date DESC, created_at DESC';
    const result = await pool.query(query);
    res.status(200).json(result.rows);
  } catch (err) {
    console.error('Помилка отримання фільмів:', err.message);
    res.status(500).json({ message: 'Внутрішня помилка сервера.' });
  }
};

const getMovieById = async (req, res) => {
  try {
    const { id } = req.params;
    const query = 'SELECT * FROM movies WHERE id = $1';
    const result = await pool.query(query, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Фільм не знайдено.' });
    }

    res.status(200).json(result.rows[0]);
  } catch (err) {
    console.error('Помилка отримання фільму:', err.message);
    res.status(500).json({ message: 'Внутрішня помилка сервера.' });
  }
};

module.exports = { getAllMovies, getMovieById };
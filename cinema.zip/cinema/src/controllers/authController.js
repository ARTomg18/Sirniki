// src/controllers/authController.js (оновлений для JWT)

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { pool } = require('../config/db');

// функція registerUser залишається без змін...
const registerUser = async (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password) {
    return res.status(400).json({ message: 'Будь ласка, надайте ім\'я, email та пароль.' });
  }
  if (password.length < 6) {
    return res.status(400).json({ message: 'Пароль має містити щонайменше 6 символів.' });
  }
  try {
    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(password, saltRounds);
    const query = `
      INSERT INTO users (username, email, password_hash)
      VALUES ($1, $2, $3)
      RETURNING id, username, email, balance, is_admin, created_at;
    `;
    const values = [username, email, passwordHash];
    const result = await pool.query(query, values);
    const newUser = result.rows[0];
    return res.status(201).json(newUser);
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ message: 'Користувач з таким іменем або email вже існує.' });
    }
    console.error('Помилка реєстрації:', err.message);
    return res.status(500).json({ message: 'Внутрішня помилка сервера.' });
  }
};


const loginUser = async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: 'Будь ласка, надайте email та пароль.' });
  }

  try {
    const query = 'SELECT * FROM users WHERE email = $1';
    const result = await pool.query(query, [email]);

    if (result.rows.length === 0) {
      return res.status(401).json({ message: 'Невірний email або пароль.' });
    }

    const user = result.rows[0];
    const isPasswordCorrect = await bcrypt.compare(password, user.password_hash);

    if (!isPasswordCorrect) {
      return res.status(401).json({ message: 'Невірний email або пароль.' });
    }
    
    // --- ЛОГІКА JWT ---
    // 1. Створюємо корисне навантаження для токена
    const payload = {
      id: user.id,
      username: user.username,
      is_admin: user.is_admin,
    };

    // 2. Підписуємо токен нашим секретним ключем
    const token = jwt.sign(
      payload,
      process.env.JWT_SECRET,
      { expiresIn: '1h' } // Токен буде дійсний 1 годину
    );
    
    delete user.password_hash;

    return res.status(200).json({
      message: 'Вхід успішний.',
      token: token, // Відправляємо токен клієнту
      user: user
    });

  } catch (err) {
    console.error('Помилка входу:', err.message);
    return res.status(500).json({ message: 'Внутрішня помилка сервера.' });
  }
};

module.exports = { registerUser, loginUser };
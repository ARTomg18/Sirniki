// src/controllers/adminController.js
const { pool } = require('../config/db');

const createMovie = async (req, res) => {
    try {
        const { title, description, poster_url, background_url, trailer_url, genre, rating, duration_minutes, cast_actors, price, is_premiere, release_date } = req.body;
        // Тут можна додати валідацію полів
        const query = `
            INSERT INTO movies (title, description, poster_url, background_url, trailer_url, genre, rating, duration_minutes, cast_actors, price, is_premiere, release_date)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
            RETURNING *;
        `;
        const values = [title, description, poster_url, background_url, trailer_url, genre, rating, duration_minutes, cast_actors, price, is_premiere, release_date];
        const result = await pool.query(query, values);
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error('Помилка створення фільму:', err);
        res.status(500).json({ message: 'Помилка сервера' });
    }
};

const updateMovie = async (req, res) => {
    try {
        const { id } = req.params;
        const { title, description, poster_url, background_url, trailer_url, genre, rating, duration_minutes, cast_actors, price, is_premiere, release_date } = req.body;
        const query = `
            UPDATE movies SET title = $1, description = $2, poster_url = $3, background_url = $4, trailer_url = $5, genre = $6, rating = $7, duration_minutes = $8, cast_actors = $9, price = $10, is_premiere = $11, release_date = $12
            WHERE id = $13
            RETURNING *;
        `;
        const values = [title, description, poster_url, background_url, trailer_url, genre, rating, duration_minutes, cast_actors, price, is_premiere, release_date, id];
        const result = await pool.query(query, values);
        if(result.rows.length === 0) return res.status(404).json({ message: 'Фільм не знайдено' });
        res.status(200).json(result.rows[0]);
    } catch (err) {
        console.error('Помилка оновлення фільму:', err);
        res.status(500).json({ message: 'Помилка сервера' });
    }
};

const deleteMovie = async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('DELETE FROM movies WHERE id = $1 RETURNING *;', [id]);
        if (result.rowCount === 0) return res.status(404).json({ message: 'Фільм не знайдено.' });
        res.status(200).json({ message: `Фільм "${result.rows[0].title}" успішно видалено.` });
    } catch (err) {
        console.error('Помилка видалення фільму:', err);
        res.status(500).json({ message: 'Помилка сервера' });
    }
};

module.exports = { createMovie, updateMovie, deleteMovie };
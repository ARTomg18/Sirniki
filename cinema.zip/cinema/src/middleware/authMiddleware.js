// src/middleware/authMiddleware.js

const jwt = require('jsonwebtoken');

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; 
  if (token == null) return res.sendStatus(401);

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user; // user тут - це наш payload { id, username, is_admin }
    next();
  });
};

// НОВА ФУНКЦІЯ
const authorizeAdmin = (req, res, next) => {
    // Ми очікуємо, що authenticateToken вже відпрацював і додав req.user
    if (req.user && req.user.is_admin) {
        next(); // Користувач - адмін, пропускаємо далі
    } else {
        res.status(403).json({ message: 'Доступ заборонено. Потрібні права адміністратора.' });
    }
};

module.exports = { authenticateToken, authorizeAdmin };
// public/js/main.js
import { initAuth, getAuthToken } from './auth.js';
import { initUI, renderMovies, populateMovieDetails, openModal, renderUserProfile, renderAdminMovieList } from './ui.js';
import * as api from './api.js';

async function loadMovies() {
    try {
        const allMovies = await api.getMovies();
        
        // Знаходимо контейнери на поточній сторінці
        const nowPlayingGrid = document.querySelector('[data-movies-grid="now-playing"]');
        const comingSoonGrid = document.querySelector('[data-movies-grid="coming-soon"]');

        // ВИПРАВЛЕНА ЛОГІКА ФІЛЬТРАЦІЇ
        // Використовуємо точне порівняння ===, щоб уникнути проблем з типами даних
        const nowPlayingMovies = allMovies.filter(movie => movie.is_premiere === false);
        const comingSoonMovies = allMovies.filter(movie => movie.is_premiere === true);

        // Рендеримо фільми тільки якщо відповідний контейнер існує
        if (nowPlayingGrid) {
            renderMovies(nowPlayingMovies, '[data-movies-grid="now-playing"]');
        }
        if (comingSoonGrid) {
            renderMovies(comingSoonMovies, '[data-movies-grid="coming-soon"]');
        }
    } catch (error) {
        console.error('Не вдалося завантажити фільми:', error);
    }
}

async function handleMovieCardClick(event) {
    const card = event.target.closest('.movie-card');
    if (!card) return;

    const movieId = card.dataset.movieId;
    try {
        const movie = await api.getMovieById(movieId);
        populateMovieDetails(movie);
        openModal('movie-details');
    } catch (error) {
        console.error('Не вдалося завантажити деталі фільму:', error);
    }
}

async function showUserProfile() {
    const token = getAuthToken();
    if (!token) return;
    try {
        const profileData = await api.getProfile(token);
        renderUserProfile(profileData);
        openModal('profile');
    } catch (error) {
        console.error('Не вдалося завантажити профіль:', error);
    }
}
window.showUserProfile = showUserProfile;

async function showAdminPanel() {
    const token = getAuthToken();
    if (!token) return;
    try {
        const movies = await api.getMovies();
        renderAdminMovieList(movies);
        openModal('admin');
    } catch (error) {
        console.error('Не вдалося завантажити дані для адмін-панелі:', error);
    }
}
window.showAdminPanel = showAdminPanel;

async function refreshAdminMovies() {
    const token = getAuthToken();
    if (!token) return;
    try {
        const movies = await api.getMovies();
        renderAdminMovieList(movies);
        // Оновлюємо також і головну сторінку, якщо ми на ній
        if (document.querySelector('[data-movies-grid="now-playing"]')) {
            loadMovies();
        }
    } catch (error) {
        console.error('Не вдалося оновити список фільмів:', error);
    }
}
window.refreshAdminMovies = refreshAdminMovies;

// --- App Initialization ---
document.addEventListener('DOMContentLoaded', () => {
    console.log('Cinema app main script loaded.');
    
    AOS.init({
        duration: 800,
        once: true,
    });

    initUI();
    initAuth();
    loadMovies();
    
    document.querySelectorAll('.movies-grid').forEach(grid => {
        grid.addEventListener('click', handleMovieCardClick);
    });
});
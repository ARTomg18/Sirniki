// public/js/ui.js
import * as api from './api.js';
import { getAuthToken, getCurrentUser, updateUserInStorage } from './auth.js';

// --- DOM Elements ---
const modals = document.querySelectorAll('.modal-overlay');
const moviesGrid = document.querySelector('[data-movies-grid]');
const movieDetailsModal = document.querySelector('[data-modal-id="movie-details"]');
const adminModal = document.querySelector('[data-modal-id="admin"]');

// --- State Variables ---
let selectedSeats = [];
let ticketPrice = 0;
let currentMovieId = null;

// --- Modal Logic ---
export function openModal(modalId) {
    const modal = document.querySelector(`[data-modal-id="${modalId}"]`);
    if (modal) {
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
}
export function closeModal(modalId) {
    const modal = document.querySelector(`[data-modal-id="${modalId}"]`);
    if (modal) {
        modal.classList.add('hidden');
        document.body.style.overflow = 'auto';
    }
}

// --- Toast/Alert Message ---
function showToast(message, isError = false) {
    const toast = document.createElement('div');
    toast.className = `toast ${isError ? 'toast--error' : ''}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => { toast.remove(); }, 3000);
}

// --- UI Updates ---
export function updateHeaderUI(isLoggedIn, userData, logoutHandler) {
    const headerActions = document.querySelector('.header__actions');
    if (!headerActions) return;

    if (isLoggedIn) {
        const adminLink = userData.is_admin ? `<a href="#" class="nav-link" data-auth="admin">Адмін-панель</a>` : '';
        headerActions.innerHTML = `
            ${adminLink}
            <a href="#" class="nav-link" data-auth="profile">${userData.username}</a>
            <button class="btn btn--secondary" data-auth="logout" data-ripple>Вийти</button>
        `;
    } else {
        headerActions.innerHTML = `
            <button class="btn btn--secondary" data-auth="login" data-ripple>Увійти</button>
            <button class="btn btn--primary" data-auth="register" data-ripple>Реєстрація</button>
        `;
    }
    initRippleForContainer(headerActions);
}

// ... (renderMovies, renderUserProfile, та вся логіка для Seat Selection і Admin Panel залишаються без змін) ...
export function renderMovies(movies, containerSelector) { /* ... */ }
export function renderUserProfile(profileData) { /* ... */ }
async function handleBookingConfirmation() { /* ... */ }
function updateSelectionSummary() { /* ... */ }
function handleSeatClick(event) { /* ... */ }
function renderSeatMap(rows, cols, occupied, price) { /* ... */ }
export function populateMovieDetails(movie) { /* ... */ }
function populateAdminForm(movie) { /* ... */ }
function clearAdminForm() { /* ... */ }
export function renderAdminMovieList(movies) { /* ... */ }
async function handleAdminFormSubmit(event) { /* ... */ }
async function handleAdminListClick(event) { /* ... */ }


// --- Ripple Effect ---
function createRipple(event) {
    const button = event.currentTarget;
    const circle = document.createElement("span");
    const diameter = Math.max(button.clientWidth, button.clientHeight);
    const radius = diameter / 2;
    circle.style.width = circle.style.height = `${diameter}px`;
    circle.style.left = `${event.clientX - (button.getBoundingClientRect().left + radius)}px`;
    circle.style.top = `${event.clientY - (button.getBoundingClientRect().top + radius)}px`;
    circle.classList.add("ripple");
    const ripple = button.getElementsByClassName("ripple")[0];
    if (ripple) { ripple.remove(); }
    button.appendChild(circle);
}

function initRippleForContainer(container) {
    const buttons = container.querySelectorAll('[data-ripple]');
    buttons.forEach(button => { button.addEventListener("click", createRipple); });
}

// --- Global UI Initializer ---
export function initUI() {
    // ВИПРАВЛЕНО: Єдиний обробник подій для всього документу (делегування)
    document.addEventListener('click', (event) => {
        const target = event.target;

        // Обробка кліків на кнопки авторизації в шапці
        const authButton = target.closest('[data-auth]');
        if (authButton && authButton.closest('.header__actions')) {
            event.preventDefault();
            const action = authButton.dataset.auth;
            switch (action) {
                case 'login':
                case 'register':
                    openModal(action);
                    break;
                case 'profile':
                    window.showUserProfile();
                    break;
                case 'admin':
                    window.showAdminPanel();
                    break;
                case 'logout':
                    // Цей клік обробляється напряму в auth.js
                    break;
            }
            return; // Зупиняємо подальшу обробку, якщо це була кнопка в шапці
        }
        
        // Обробка кліку на кнопку закриття модалки
        const closeButton = target.closest('.modal-close-btn');
        if (closeButton) {
            const modal = closeButton.closest('.modal-overlay');
            if (modal) closeModal(modal.dataset.modalId);
            return;
        }

        // Обробка кліку на оверлей модалки
        if (target.matches('.modal-overlay')) {
             if (target.dataset.modalId === 'movie-details') {
                const iframe = target.querySelector('iframe');
                const trailerSection = target.querySelector('[data-details="trailer-section"]');
                const seatSection = target.querySelector('[data-details="seat-selection"]');
                if (iframe) iframe.src = '';
                if (trailerSection) trailerSection.classList.add('hidden');
                if (seatSection) seatSection.classList.add('hidden');
             }
            closeModal(target.dataset.modalId);
            return;
        }

        // Обробка кліку на кнопку очищення адмін-форми
        const clearFormButton = target.closest('[data-action="clear-form"]');
        if(clearFormButton) {
            clearAdminForm();
            return;
        }
    });

    // Ініціалізація Ripple для статичних кнопок при завантаженні
    initRippleForContainer(document.body);
    
    // Слухачі для форм (вони статичні, тому можна тут)
    const adminMovieForm = document.querySelector('#admin-movie-form');
    if (adminMovieForm) {
        adminMovieForm.addEventListener('submit', handleAdminFormSubmit);
    }
    const adminMovieList = document.querySelector('[data-admin="movies-list"]');
    if(adminMovieList) {
        adminMovieList.addEventListener('click', handleAdminListClick);
    }
}
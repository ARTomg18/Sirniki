// public/js/api.js
const BASE_URL = '/api';

async function request(endpoint, options = {}) {
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers,
    };
    const config = {
        method: options.method || 'GET',
        ...options,
        headers,
    };
    if (options.body) {
        config.body = JSON.stringify(options.body);
    }
    const response = await fetch(`${BASE_URL}${endpoint}`, config);
    const data = await response.json();
    if (!response.ok) {
        throw new Error(data.message || 'Щось пішло не так');
    }
    return data;
}

export const login = (email, password) => request('/login', { method: 'POST', body: { email, password } });
export const register = (username, email, password) => request('/register', { method: 'POST', body: { username, email, password } });
export const getMovies = () => request('/movies');
export const getMovieById = (id) => request(`/movies/${id}`);
export const bookTickets = (bookingData, token) => request('/tickets/book', { method: 'POST', body: bookingData, headers: { 'Authorization': `Bearer ${token}` } });
export const getProfile = (token) => request('/profile', { headers: { 'Authorization': `Bearer ${token}` } });

// НОВІ ФУНКЦІЇ ДЛЯ АДМІНА
export const createMovie = (movieData, token) => request('/admin/movies', { method: 'POST', body: movieData, headers: { 'Authorization': `Bearer ${token}` } });
export const updateMovie = (id, movieData, token) => request(`/admin/movies/${id}`, { method: 'PUT', body: movieData, headers: { 'Authorization': `Bearer ${token}` } });
export const deleteMovie = (id, token) => request(`/admin/movies/${id}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${token}` } });
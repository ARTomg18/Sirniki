// public/js/auth.js
import { login, register } from './api.js';
import { openModal, closeModal, updateHeaderUI } from './ui.js';

const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');

function saveAuthData({ token, user }) {
    localStorage.setItem('authToken', token);
    localStorage.setItem('userData', JSON.stringify(user));
}

function clearAuthData() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('userData');
}

export function getAuthToken() {
    return localStorage.getItem('authToken');
}

export function getCurrentUser() {
    try {
        return JSON.parse(localStorage.getItem('userData'));
    } catch (e) {
        return null;
    }
}

export function updateUserInStorage(newUserData) {
    const currentUser = getCurrentUser();
    if (currentUser) {
        const updatedUser = { ...currentUser, ...newUserData };
        localStorage.setItem('userData', JSON.stringify(updatedUser));
    }
}

async function handleLogin(event) {
    event.preventDefault();
    const errorEl = loginForm.querySelector('[data-form-error]');
    errorEl.textContent = '';
    const email = event.target.elements['login-email'].value;
    const password = event.target.elements['login-password'].value;
    try {
        const data = await login(email, password);
        saveAuthData(data);
        updateHeaderUI(true, data.user, handleLogout);
        closeModal('login');
    } catch (error) {
        errorEl.textContent = error.message;
    }
}

async function handleRegister(event) {
    event.preventDefault();
    const errorEl = registerForm.querySelector('[data-form-error]');
    errorEl.textContent = '';
    const username = event.target.elements['register-username'].value;
    const email = event.target.elements['register-email'].value;
    const password = event.target.elements['register-password'].value;
    try {
        await register(username, email, password);
        closeModal('register');
        openModal('login');
    } catch (error) {
        errorEl.textContent = error.message;
    }
}

function handleLogout() {
    clearAuthData();
    updateHeaderUI(false, null, handleLogout);
    window.location.hash = '';
    window.location.reload();
}

function checkInitialAuthState() {
    const token = getAuthToken();
    const userData = getCurrentUser();
    if (token && userData) {
        updateHeaderUI(true, userData, handleLogout);
    } else {
        updateHeaderUI(false, null, handleLogout);
    }
}

export function initAuth() {
    if (loginForm) loginForm.addEventListener('submit', handleLogin);
    if (registerForm) registerForm.addEventListener('submit', handleRegister);
    checkInitialAuthState();
}
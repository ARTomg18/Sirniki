// server.js
require('dotenv').config();
const express = require('express');
const path = require('path');

const authRoutes = require('./src/routes/authRoutes');
const userRoutes = require('./src/routes/userRoutes');
const movieRoutes = require('./src/routes/movieRoutes');
const ticketRoutes = require('./src/routes/ticketRoutes');
const adminRoutes = require('./src/routes/adminRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// API роутери
app.use('/api', authRoutes);
app.use('/api', userRoutes);
app.use('/api', movieRoutes);
app.use('/api', ticketRoutes);
app.use('/api/admin', adminRoutes);

// Роздача статичних файлів (CSS, JS, images)
app.use(express.static(path.join(__dirname, 'public')));

// НОВІ МАРШРУТИ ДЛЯ СТОРІНОК
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/soon', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'soon.html'));
});

app.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'about.html'));
});

// Обробник для 404 помилки (якщо жоден маршрут не підійшов)
app.use((req, res) => {
    res.status(404).send("Сторінку не знайдено");
});

app.listen(PORT, () => {
  console.log(`Сервер успішно запущено на порту ${PORT}`);
});
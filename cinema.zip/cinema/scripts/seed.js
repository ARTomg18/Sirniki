// scripts/seed.js

// Вказуємо шлях до .env файлу, оскільки скрипт знаходиться в іншій папці
require('dotenv').config({ path: './.env' });

const { pool } = require('../src/config/db');

const initialMovies = [
  {
    title: "Дюна: Частина друга",
    description: "Поль Атрейдес об'єднується з Чані та фременами, стаючи на шлях помсти змовникам, які знищили його родину.",
    poster_url: "https://image.tmdb.org/t/p/w500/8b8R8l88Qje9dn9OE8aaBtsjsM.jpg",
    background_url: "https://image.tmdb.org/t/p/w1280/xOMo8BRK7Pkr4KiL7sfm9gKq2dy.jpg",
    trailer_url: "https://www.youtube.com/embed/Way9_12gV1I",
    genre: "Наукова фантастика, Пригоди",
    rating: "8.3/10",
    duration_minutes: 166,
    cast_actors: "Тімоті Шаламе, Зендея, Ребекка Фергюсон",
    price: 190.00,
    is_premiere: true,
    release_date: "2024-02-27"
  },
  {
    title: "Оппенгеймер",
    description: "Історія життя американського фізика-теоретика Роберта Оппенгеймера, якого називають «батьком атомної бомби».",
    poster_url: "https://image.tmdb.org/t/p/w500/sY5g4sKRd361t0n2iAlS13dFF1P.jpg",
    background_url: "https://image.tmdb.org/t/p/w1280/fm6KqXpk3M2HVveHwCrBSSBaO0V.jpg",
    trailer_url: "https://www.youtube.com/embed/bK6ldnjE3Y0",
    genre: "Біографія, Драма, Історія",
    rating: "8.6/10",
    duration_minutes: 180,
    cast_actors: "Кілліан Мерфі, Емілі Блант, Метт Деймон",
    price: 180.00,
    is_premiere: false,
    release_date: "2023-07-19"
  },
  {
    title: "Інтерстеллар",
    description: "Подорож групи дослідників, які використовують щойно виявлений червоточину, щоб перевершити обмеження людських космічних подорожей і підкорити величезні відстані.",
    poster_url: "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg",
    background_url: "https://image.tmdb.org/t/p/w1280/vL5LR6WdxIhTTIjpTLgCcI1Eigx.jpg",
    trailer_url: "https://www.youtube.com/embed/zSWdZVtXT7E",
    genre: "Пригоди, Драма, Наукова фантастика",
    rating: "8.4/10",
    duration_minutes: 169,
    cast_actors: "Меттью Мак-Конегі, Енн Гетевей, Джессіка Честейн",
    price: 150.00,
    is_premiere: false,
    release_date: "2014-11-05"
  },
  // Можеш додати ще фільмів за аналогією
];

const seedDatabase = async () => {
  try {
    console.log('Починаємо засів бази даних...');
    
    // Очищуємо таблицю перед засівом, щоб уникнути дублікатів
    await pool.query('TRUNCATE TABLE movies RESTART IDENTITY CASCADE;');
    console.log('Таблицю movies очищено.');

    for (const movie of initialMovies) {
      const query = `
        INSERT INTO movies 
          (title, description, poster_url, background_url, trailer_url, genre, rating, duration_minutes, cast_actors, price, is_premiere, release_date) 
        VALUES 
          ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12);
      `;
      const values = [
        movie.title, movie.description, movie.poster_url, movie.background_url,
        movie.trailer_url, movie.genre, movie.rating, movie.duration_minutes,
        movie.cast_actors, movie.price, movie.is_premiere, movie.release_date
      ];

      await pool.query(query, values);
      console.log(`Додано фільм: ${movie.title}`);
    }

    console.log('Засів бази даних успішно завершено.');
  } catch (err) {
    console.error('Помилка під час засіву бази даних:', err);
  } finally {
    // Дуже важливо закрити пул підключень, коли скрипт завершив роботу
    await pool.end();
    console.log('Підключення до бази даних закрито.');
  }
};

seedDatabase();